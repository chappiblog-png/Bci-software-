import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _identifierController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _loading = false;

  Future<void> _login() async {
    setState(() => _loading = true);
    // Wire to AuthApiClient.login(identifier, password) here — calls
    // POST /auth/login on the BCI backend and stores the returned tokens.
    await Future.delayed(const Duration(milliseconds: 400));
    setState(() => _loading = false);
    if (mounted) context.go('/dashboard');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('BCI', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const Text('Business Command Intelligence', style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 32),
              TextField(
                controller: _identifierController,
                decoration: const InputDecoration(labelText: 'Mobile number or email', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 20),
              FilledButton(
                onPressed: _loading ? null : _login,
                child: _loading ? const CircularProgressIndicator() : const Text('Log In'),
              ),
              TextButton(onPressed: () {}, child: const Text('Forgot password?')),
              const Divider(height: 32),
              OutlinedButton(onPressed: () {}, child: const Text('Create a new account')),
            ],
          ),
        ),
      ),
    );
  }
}
