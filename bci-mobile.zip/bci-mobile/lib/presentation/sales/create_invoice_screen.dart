import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../sync/sync_service.dart';
import '../../core/local_stubs.dart';

// Concrete in-memory implementations so the app runs standalone out of the
// box. Swap these for the real Drift-backed + HTTP-backed implementations
// (see /home/claude/bci-backend for the matching server API) when wiring
// up the live backend — the interfaces are unchanged.
final SyncService syncService = SyncService(
  localDb: InMemorySyncQueueStore(),
  apiClient: NoopSyncApiClient(),
  deviceId: 'local-dev-device',
);
final LocalInvoiceRepository localInvoiceRepo = InMemoryInvoiceRepository();


/// BCI — Create Sales Invoice screen.
/// Offline-first: saves to local Drift DB immediately, then queues a
/// sync_log entry for the background SyncService to push when online.
class CreateInvoiceScreen extends StatefulWidget {
  const CreateInvoiceScreen({super.key});

  @override
  State<CreateInvoiceScreen> createState() => _CreateInvoiceScreenState();
}

class _InvoiceLine {
  String itemName = '';
  double qty = 1;
  double rate = 0;
  double taxPct = 18;

  double get taxableValue => qty * rate;
  double get taxAmount => taxableValue * taxPct / 100;
  double get lineTotal => taxableValue + taxAmount;
}

class _CreateInvoiceScreenState extends State<CreateInvoiceScreen> {
  String? selectedPartyName;
  final List<_InvoiceLine> _lines = [_InvoiceLine()];
  double amountReceived = 0;

  double get taxableTotal => _lines.fold(0, (s, l) => s + l.taxableValue);
  double get taxTotal => _lines.fold(0, (s, l) => s + l.taxAmount);
  double get grandTotal => taxableTotal + taxTotal;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New Sale Invoice'),
        actions: [
          IconButton(
            icon: const Icon(Icons.qr_code_scanner),
            onPressed: _scanBarcode,
            tooltip: 'Scan item barcode',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildPartyPicker(),
          const SizedBox(height: 16),
          const Text('Items', style: TextStyle(fontWeight: FontWeight.bold)),
          ..._lines.asMap().entries.map((e) => _buildLineCard(e.key, e.value)),
          TextButton.icon(
            onPressed: () => setState(() => _lines.add(_InvoiceLine())),
            icon: const Icon(Icons.add),
            label: const Text('Add Item'),
          ),
          const Divider(),
          _buildTotalsSummary(),
          const SizedBox(height: 12),
          _buildAmountReceivedField(),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _saveInvoice(asDraft: true),
                  child: const Text('Save as Draft'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () => _saveInvoice(asDraft: false),
                  child: const Text('Save & Share'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPartyPicker() {
    return InkWell(
      onTap: _pickParty,
      child: InputDecorator(
        decoration: const InputDecoration(
          labelText: 'Customer',
          border: OutlineInputBorder(),
          suffixIcon: Icon(Icons.person_search),
        ),
        child: Text(selectedPartyName ?? 'Select or add customer'),
      ),
    );
  }

  Widget _buildLineCard(int index, _InvoiceLine line) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            TextFormField(
              decoration: const InputDecoration(labelText: 'Item name / SKU'),
              initialValue: line.itemName,
              onChanged: (v) => setState(() => line.itemName = v),
            ),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    decoration: const InputDecoration(labelText: 'Qty'),
                    keyboardType: TextInputType.number,
                    initialValue: line.qty.toString(),
                    onChanged: (v) =>
                        setState(() => line.qty = double.tryParse(v) ?? 0),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    decoration: const InputDecoration(labelText: 'Rate'),
                    keyboardType: TextInputType.number,
                    initialValue: line.rate.toString(),
                    onChanged: (v) =>
                        setState(() => line.rate = double.tryParse(v) ?? 0),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    decoration: const InputDecoration(labelText: 'Tax %'),
                    keyboardType: TextInputType.number,
                    initialValue: line.taxPct.toString(),
                    onChanged: (v) =>
                        setState(() => line.taxPct = double.tryParse(v) ?? 0),
                  ),
                ),
              ],
            ),
            Align(
              alignment: Alignment.centerRight,
              child: Text('₹${line.lineTotal.toStringAsFixed(2)}',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalsSummary() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text('Taxable: ₹${taxableTotal.toStringAsFixed(2)}'),
        Text('Tax: ₹${taxTotal.toStringAsFixed(2)}'),
        Text('Grand Total: ₹${grandTotal.toStringAsFixed(2)}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _buildAmountReceivedField() {
    return TextFormField(
      decoration: const InputDecoration(
        labelText: 'Amount Received',
        border: OutlineInputBorder(),
      ),
      keyboardType: TextInputType.number,
      onChanged: (v) => setState(() => amountReceived = double.tryParse(v) ?? 0),
    );
  }

  void _pickParty() {
    // Opens PartyPickerScreen (search local Drift cache first, remote fallback)
  }

  void _scanBarcode() {
    // Opens camera barcode scanner -> resolves item -> appends a new _InvoiceLine
  }

  Future<void> _saveInvoice({required bool asDraft}) async {
    final localInvoiceId = const Uuid().v4();

    // 1. Write invoice + lines to local Drift DB immediately (offline-first).
    await localInvoiceRepo.insert(
      id: localInvoiceId,
      partyName: selectedPartyName,
      status: asDraft ? 'draft' : 'final',
      lines: _lines
          .map((l) => {'itemName': l.itemName, 'qty': l.qty, 'rate': l.rate, 'taxPct': l.taxPct})
          .toList(),
      amountReceived: amountReceived,
      grandTotal: grandTotal, // preview total; server GstCalculationService is authoritative
    );

    // 2 & 3. Queue the mutation and let SyncService push it (immediately if
    // online; the queued row survives app restarts and is retried later if not).
    await syncService.queueMutation(
      entityType: 'sales_invoice',
      entityId: localInvoiceId,
      operation: 'create',
      payload: {
        'partyName': selectedPartyName,
        'status': asDraft ? 'draft' : 'final',
        'items': _lines
            .map((l) => {'itemName': l.itemName, 'qty': l.qty, 'rate': l.rate, 'taxPct': l.taxPct})
            .toList(),
        'amountReceived': amountReceived,
      },
    );

    if (mounted) Navigator.of(context).pop();
  }
}
