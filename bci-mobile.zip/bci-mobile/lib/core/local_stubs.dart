import '../sync/sync_service.dart';

/// Local persistence contract for invoices — swap the in-memory
/// implementation below for a Drift (SQLite) table per the schema in
/// bci-backend/src/database/migrations/001_init_schema.sql
/// (sales_invoices / sales_invoice_items) when wiring persistent storage.
abstract class LocalInvoiceRepository {
  Future<void> insert({
    required String id,
    required String? partyName,
    required String status,
    required List<Map<String, dynamic>> lines,
    required double amountReceived,
    required double grandTotal,
  });
}

class InMemoryInvoiceRepository implements LocalInvoiceRepository {
  final List<Map<String, dynamic>> _invoices = [];

  @override
  Future<void> insert({
    required String id,
    required String? partyName,
    required String status,
    required List<Map<String, dynamic>> lines,
    required double amountReceived,
    required double grandTotal,
  }) async {
    _invoices.add({
      'id': id,
      'partyName': partyName,
      'status': status,
      'lines': lines,
      'amountReceived': amountReceived,
      'grandTotal': grandTotal,
    });
  }

  List<Map<String, dynamic>> get all => List.unmodifiable(_invoices);
}

/// Temporary in-memory sync queue — replace with the Drift-backed store
/// described in sync_service.dart's LocalSyncQueueStore contract.
class InMemorySyncQueueStore implements LocalSyncQueueStore {
  final List<QueuedMutation> _queue = [];
  final Set<String> _synced = {};
  final Map<String, String> _conflicts = {};
  String? _lastPulledAt;

  @override
  Future<void> insertQueuedMutation({
    required String clientMutationId,
    required String entityType,
    required String entityId,
    required String operation,
    required String clientTimestamp,
    required String payloadJson,
  }) async {
    _queue.add(QueuedMutation(
      clientMutationId: clientMutationId,
      entityType: entityType,
      entityId: entityId,
      operation: operation,
      clientTimestamp: clientTimestamp,
      payloadJson: payloadJson,
    ));
  }

  @override
  Future<List<QueuedMutation>> getPendingMutations() async =>
      _queue.where((m) => !_synced.contains(m.clientMutationId)).toList();

  @override
  Future<void> markMutationSynced(String clientMutationId) async => _synced.add(clientMutationId);

  @override
  Future<void> markMutationConflict(String clientMutationId, {required String serverVersionJson, required String reason}) async {
    _conflicts[clientMutationId] = reason;
  }

  @override
  Future<int> countPending() async => _queue.length - _synced.length;

  @override
  Future<int> countConflicts() async => _conflicts.length;

  @override
  Future<String?> getLastPulledAt() async => _lastPulledAt;

  @override
  Future<void> setLastPulledAt(String timestamp) async => _lastPulledAt = timestamp;

  @override
  Future<void> applyRemoteChange(Map<String, dynamic> change) async {
    // No-op until the backend is connected.
  }
}

/// Placeholder network client — returns immediately without contacting a
/// server. Replace with an http-based implementation pointing at the BCI
/// backend's /sync/push and /sync/pull endpoints once deployed.
class NoopSyncApiClient implements SyncApiClient {
  @override
  Future<SyncPushResponse> pushBatch({required String deviceId, required List<QueuedMutation> mutations}) async {
    return SyncPushResponse(
      mutations
          .map((m) => SyncPushResult(clientMutationId: m.clientMutationId, status: 'applied'))
          .toList(),
    );
  }

  @override
  Future<SyncPullResponse> pull({String? since, required String deviceId}) async {
    return SyncPullResponse(changes: const [], serverTime: DateTime.now().toUtc().toIso8601String());
  }
}
