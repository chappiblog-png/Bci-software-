import 'dart:async';
import 'dart:convert';
import 'package:uuid/uuid.dart';

/// BCI Mobile Sync Service — the client-side half of the Cloud Sync Engine.
/// Every local write goes through [queueMutation] immediately (offline-first:
/// the UI never blocks on network). A connectivity listener + periodic timer
/// call [pushPending] to flush the queue when a connection is available.
class SyncService {
  SyncService({
    required this.localDb,
    required this.apiClient,
    required this.deviceId,
  });

  final LocalSyncQueueStore localDb;
  final SyncApiClient apiClient;
  final String deviceId;
  final _uuid = const Uuid();

  bool _isSyncing = false;
  final _statusController = StreamController<SyncStatus>.broadcast();
  Stream<SyncStatus> get statusStream => _statusController.stream;

  /// Called by every screen's save action right after writing to the local
  /// Drift DB. Never throws — queueing is local-only and always succeeds;
  /// network failure is handled entirely inside [pushPending].
  Future<void> queueMutation({
    required String entityType,
    required String entityId,
    required String operation, // create/update/delete
    required Map<String, dynamic> payload,
  }) async {
    await localDb.insertQueuedMutation(
      clientMutationId: _uuid.v4(),
      entityType: entityType,
      entityId: entityId,
      operation: operation,
      clientTimestamp: DateTime.now().toUtc().toIso8601String(),
      payloadJson: jsonEncode(payload),
    );
    // Fire-and-forget: attempt an immediate push, but don't make the caller
    // wait for it — the queued row is already durable on disk.
    unawaited(pushPending());
  }

  /// Pushes all queued mutations in a single batch call. Safe to call
  /// repeatedly/concurrently — guarded by [_isSyncing] — and safe to retry
  /// after a partial failure because the server dedupes by clientMutationId.
  Future<void> pushPending() async {
    if (_isSyncing) return;
    _isSyncing = true;
    _statusController.add(SyncStatus.syncing);

    try {
      final pending = await localDb.getPendingMutations();
      if (pending.isEmpty) {
        _statusController.add(SyncStatus.idle);
        return;
      }

      final response = await apiClient.pushBatch(
        deviceId: deviceId,
        mutations: pending,
      );

      for (final result in response.results) {
        switch (result.status) {
          case 'applied':
          case 'duplicate_ignored':
            await localDb.markMutationSynced(result.clientMutationId);
            break;
          case 'conflict':
            await localDb.markMutationConflict(
              result.clientMutationId,
              serverVersionJson: jsonEncode(result.serverVersion),
              reason: result.reason ?? 'Unknown conflict',
            );
            _statusController.add(SyncStatus.conflictsPending);
            break;
          case 'rejected':
            // Leave it queued (still 'pending' locally) — will retry on the
            // next push, e.g. after the user fixes the underlying issue.
            break;
        }
      }

      // Pull server-side changes made by other devices/team members since
      // our last successful sync.
      await _pullRemoteChanges();

      _statusController.add(SyncStatus.idle);
    } catch (e) {
      // Network error, server unreachable, etc. — mutations remain queued
      // locally; nothing is lost. Will retry on next connectivity event.
      _statusController.add(SyncStatus.offline);
    } finally {
      _isSyncing = false;
    }
  }

  Future<void> _pullRemoteChanges() async {
    final lastSyncedAt = await localDb.getLastPulledAt();
    final pullResult = await apiClient.pull(since: lastSyncedAt, deviceId: deviceId);

    for (final change in pullResult.changes) {
      await localDb.applyRemoteChange(change);
    }

    await localDb.setLastPulledAt(pullResult.serverTime);
  }

  /// Surfaced in Settings > Active Devices / Sync as a manual "pull to
  /// refresh" plus a badge count of unresolved conflicts needing review.
  Future<SyncSummary> getSummary() async {
    final pendingCount = await localDb.countPending();
    final conflictCount = await localDb.countConflicts();
    final lastSyncedAt = await localDb.getLastPulledAt();
    return SyncSummary(
      pendingCount: pendingCount,
      conflictCount: conflictCount,
      lastSyncedAt: lastSyncedAt,
    );
  }

  void dispose() => _statusController.close();
}

enum SyncStatus { idle, syncing, offline, conflictsPending }

class SyncSummary {
  SyncSummary({required this.pendingCount, required this.conflictCount, this.lastSyncedAt});
  final int pendingCount;
  final int conflictCount;
  final String? lastSyncedAt;
}

class QueuedMutation {
  QueuedMutation({
    required this.clientMutationId,
    required this.entityType,
    required this.entityId,
    required this.operation,
    required this.clientTimestamp,
    required this.payloadJson,
  });
  final String clientMutationId;
  final String entityType;
  final String entityId;
  final String operation;
  final String clientTimestamp;
  final String payloadJson;

  Map<String, dynamic> toJson() => {
        'clientMutationId': clientMutationId,
        'entityType': entityType,
        'entityId': entityId,
        'operation': operation,
        'clientTimestamp': clientTimestamp,
        'payload': jsonDecode(payloadJson),
      };
}

class SyncPushResult {
  SyncPushResult({required this.clientMutationId, required this.status, this.reason, this.serverVersion});
  final String clientMutationId;
  final String status; // applied/duplicate_ignored/conflict/rejected
  final String? reason;
  final dynamic serverVersion;
}

class SyncPushResponse {
  SyncPushResponse(this.results);
  final List<SyncPushResult> results;
}

class SyncPullResponse {
  SyncPullResponse({required this.changes, required this.serverTime});
  final List<Map<String, dynamic>> changes;
  final String serverTime;
}

/// Local persistence contract (implemented via Drift/SQLite in the real app).
abstract class LocalSyncQueueStore {
  Future<void> insertQueuedMutation({
    required String clientMutationId,
    required String entityType,
    required String entityId,
    required String operation,
    required String clientTimestamp,
    required String payloadJson,
  });
  Future<List<QueuedMutation>> getPendingMutations();
  Future<void> markMutationSynced(String clientMutationId);
  Future<void> markMutationConflict(String clientMutationId, {required String serverVersionJson, required String reason});
  Future<int> countPending();
  Future<int> countConflicts();
  Future<String?> getLastPulledAt();
  Future<void> setLastPulledAt(String timestamp);
  Future<void> applyRemoteChange(Map<String, dynamic> change);
}

/// Network contract — thin wrapper over POST /sync/push and GET /sync/pull.
abstract class SyncApiClient {
  Future<SyncPushResponse> pushBatch({required String deviceId, required List<QueuedMutation> mutations});
  Future<SyncPullResponse> pull({String? since, required String deviceId});
}
