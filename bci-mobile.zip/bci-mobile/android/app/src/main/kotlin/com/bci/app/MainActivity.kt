package com.bci.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
